#
# This is the user-interface definition of a Shiny web application. You can
# run the application by clicking 'Run App' above.
#
# Find out more about building applications with Shiny here:
# 
#    http://shiny.rstudio.com/
#

library(shiny)

# Define UI for miles per gallon application
shinyUI(pageWithSidebar(
  
  # Application title
  headerPanel("Haemonchus contortus Q0 model"),
  
  sidebarPanel(
    
    h2("Model input"),
    # Input: Select a file ----
    fileInput("file1", "Choose CSV file containing daily temperature and rainfall data",
              multiple = TRUE,
              accept = c(".csv")),
    # Input: Checkbox if file has header ----
    checkboxInput("header", "Header", TRUE),
    # Input: Select separator ----
    radioButtons("sep", "Separator",
                 choices = c(Comma = ",",
                             Semicolon = ";",
                             Tab = "\t"),
                 selected = ","),
    
    # Input: Select number of rows to display ----
    radioButtons("disp", "Display",
                 choices = c(Head = "head",
                             All = "all"),
                 selected = "head"),
    # Horizontal line ----
    tags$hr(),
    
    # Input: Select quotes ----
    numericInput("temp", "Temperature column number (in selected .csv file):", 2),
    numericInput("temp_replace", "Temperature value to replace:", 0),
    numericInput("temp_replacewith", "...replace with:", 0),
    numericInput("temp_factor", "Temperature multiplication factor:", 1),
    # Horizontal line ----
    tags$hr(),
    
    numericInput("precip", "Rainfall column number (in selected .csv file):", 3),
    numericInput("precip_replace", "Rainfall value to replace:", 0),
    numericInput("precip_replacewith", "...replace with:", 0),
    numericInput("precip_factor", "Rainfall multiplication factor:", 1),
    # Horizontal line ----
    tags$hr(),
    
    numericInput("latitude", "Latitude of study site (in decimal degrees)", 52),
    # Horizontal line ----
    tags$hr(),
    
    textInput("ss", "Start date (must be in the format 'YYYY-MM-DD')", "2018-01-01"),
    textInput("ee", "End date (must be in the format 'YYYY-MM-DD')", "2018-01-01"),
    # Horizontal line ----
    tags$hr(),
    
    numericInput("stockingRate", "[OPTIONAL] Stocking rate (sheep per unit area):", 1),
    
    
    
    # Horizontal line ----
    tags$hr(),
    h2('Download the Q0 output'),

    downloadButton('download', 'Download data to:')
    
   
    
  ),
 
  # Main panel for displaying outputs ----
  mainPanel(
    img(src = "UoLlogo.png", height = 102, width = 400),
    h2("Permissions to use this app"),
    p("If you have been given this app by anyone other than Hannah Vineer or Eric Morgan, please contact Hannah Vineer (hannah.vineer@liverpool.ac.uk) prior to use. The use of R, R Studio and any R code is covered by a GPL-3 licence and you will not be prevented from using this model. However, the authors would like to track the model's use to ensure there is no duplication of effort and that the correct sources are cited."),
    
    h3("About the Q0 model"),
    p("A model of the basic reproductive quotient of macroparasites, Q0, was adapted to Haemonchus contortus and extended to incorporate environmental stochasticity and parasite behaviour (Rose et al. 2015)."),
    p("Q0 estimates the average number of second-generation mature adult worms produced by a single adult worm during its lifetime in the absence of density-dependent constraints such as immunity and within-host competition. "),
    h3("Further details and citation"),
    p("Rose, H. , Caminade, C. , Bolajoko, M. B., Phelan, P. , Dijk, J. , Baylis, M. , Williams, D. and Morgan, E. R. (2016), Climate-driven changes to the spatio-temporal distribution of the parasitic nematode, Haemonchus contortus, in sheep in Europe. Glob Change Biol, 22: 1271-1285",
      a("doi:10.1111/gcb.13132", 
        href = "doi:10.1111/gcb.13132")),
    h3("How to use this Shiny app"),
    p("Enter all data requested in the sidepanel to the left. You will need to format your daily mean air temperature and daily total rainfall data in a .csv file, with one column containing the temperature data and one containing the rainfall data."),
    p("If your data have been multiplied (e.g. it is common for climatic data to be multiplied by 10), ensure you account for this using the multiplication factor options"),
    p("This app is able to conduct simple replacements. E.g. rainfall data may record a 'no data value' such as -1 to represent very small amounts of rainfall, as a way of differentiating these days from days withe zero rainfall. In this case you may wish to replace the -1 with 0 or perhaps a small value such as 0.05."),
    p("If you need to make more complex data corrections, such as converting between Kelvin and degrees C, this will need to be done before you import your data."),
    br(),
    p("The stocking rate entry is optional. As you will usually be looking only at relative changes in Q0 over time, this is not needed. However, if you are looking at spatial differences and each site uses a very different stocking rate, then this function might be useful. See Rose et al., (2015) for an illustration of how stocking rate affects predictions."),
    p("If you receive errors such as 'undefined columns selected' then it is likely that you have specified the incorrect separator type, or you have specified the incorrect column number for the temperature and/or rainfall data."),
    p("If you receive errors about variable lengths, it is likely that the start and end dates you have chosen do not correspond to the length of your dataset."),
    p("Note: due to a moving average function used in this model, the first and last 4 data points will display 'NA'."),
    br(),
    h2("Your data and output"),
    
    # Output: Data file ----
    tableOutput("data"),
    plotOutput("Q0plot"),
    plotOutput("tempplot"),
    plotOutput("precipplot")
)))
