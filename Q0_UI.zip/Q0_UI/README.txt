To run the RShiny app, open R and execute the following lines of code:
(Note: you may need to install the shiny, geosphere and forecast packages first).

library(shiny)
library(geosphere)
library(forecast)
runUrl("https://github.com/rstudio/shiny_example/archive/master.zip")