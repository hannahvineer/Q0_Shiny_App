#
# This is the server logic of a Shiny web application. You can run the 
# application by clicking 'Run App' above.
#
# Find out more about building applications with Shiny here:
# 
#    http://shiny.rstudio.com/
#

library(shiny)
library(geosphere)
library(forecast)

options(shiny.maxRequestSize=30*1024^2)

# Define server logic required to draw a histogram
shinyServer(function(input, output) {
   
  q0 = function(start, end, temp, precip, lat, stockingRate) {
      date.range = seq(as.Date(start), as.Date(end), "days")
      photoperiod = daylength(lat = lat, doy = date.range)
      Pt=(4.95*exp(0.062*temp))/100
      PET = 0.55*((photoperiod/12)^2)*Pt*25.4
      PE = ma(precip, order = 9, centre = TRUE)/ma(PET, order = 9, centre = TRUE)
      dev = pmax(0, -0.09746+0.01063*temp)
      mue = pmin(1, exp(-1.3484 - 0.10488*temp + 0.00230*(temp^2)))
      mul3 = pmin(1, exp(-2.62088 - 0.14399*temp + 0.00462*(temp^2)))
      m1 = 0.25
      rho = mul3/3
      m2 = 0.2
      p = 0.4
      cDM = 1.4
      B = 2000
      A = 1
      beta = cDM/(B*A)
      H = stockingRate
      lambda = 2250
      mu = 0.05
      q = ifelse(PE<1, 0, pmax(0,(dev*m1)/((mue+dev)*(mul3+m1)))) #equation 2
      Q0 = pmax(0, ((q*lambda)/mu)*((beta*p)/(rho + beta*H))*H*m2) #equation 3

    return(Q0)
  }
  
  datacalc <- reactive({
    # input$file1 will be NULL initially. After the user selects
    # and uploads a file, head of that data file by default,
    # or all rows if selected, will be shown.
    
    req(input$file1)
    
    df <- read.csv(input$file1$datapath,
                   header = input$header,
                   sep = input$sep,
                   quote = input$quote)
    
    Date_YYYYMMDD = as.character(seq(as.Date(input$ss), as.Date(input$ee), "days"))
    df = cbind(df, date = Date_YYYYMMDD)
    #temp = df[,input$temp]
    #precip = df[,input$precip]
    temp.ind = input$temp
    precip.ind = input$precip
    df[, temp.ind] = replace(x = df[, temp.ind], list = df[, temp.ind] == input$temp_replace, values = input$temp_replacewith)
    df[, precip.ind] = replace(x = df[, precip.ind], list = df[, precip.ind] == input$precip_replace, values = input$precip_replacewith)
    
    
    Q0.calc = q0(start = input$ss, end = input$ee, temp = df[,temp.ind]/input$temp_factor, precip = df[,precip.ind]/input$precip_factor, lat = input$latitude, stockingRate = input$stockingRate)
    df2 = cbind(date = Date_YYYYMMDD, temp = df[,temp.ind]/input$temp_factor, rain = df[,precip.ind]/input$precip_factor, Q0 = Q0.calc)
  })
  
  output$data <- renderTable({

  if(input$disp == "head") {
    return(head(datacalc()))
  }
  else {
    return(datacalc())
  }

  })
  
  output$Q0plot <- renderPlot({
    df = datacalc()
    Date_YYYYMMDD = as.character(seq(as.Date(input$ss), as.Date(input$ee), "days"))
    plot(df[,'Q0'], ylab = 'Q0', xaxt = 'n', xlab = '', type = 'l')
    axis(1, at = seq(1,length(Date_YYYYMMDD),1),labels = Date_YYYYMMDD)
  })
  
  output$tempplot <- renderPlot({
    df = datacalc()
    Date_YYYYMMDD = as.character(seq(as.Date(input$ss), as.Date(input$ee), "days"))
    plot(df[,'temp'], ylab = 'Temperature (degrees C)', xlab = '', xaxt = 'n', type = 'l')
    axis(1, at = seq(1,length(Date_YYYYMMDD),1),labels = Date_YYYYMMDD)
  })
  
  output$precipplot <- renderPlot({
    df = datacalc()
    Date_YYYYMMDD = as.character(seq(as.Date(input$ss), as.Date(input$ee), "days"))
    plot(df[,'rain'], ylab = 'Rainfall (mm)', xlab = '', xaxt = 'n', type = 'l')
    axis(1, at = seq(1,length(Date_YYYYMMDD),1),labels = Date_YYYYMMDD)
  })
  
  output$download <- downloadHandler(
    filename = function() {'Q0_output.csv'},
     content = function(file) {
      write.csv(datacalc(), file, row.names = FALSE)
    })
  
})
